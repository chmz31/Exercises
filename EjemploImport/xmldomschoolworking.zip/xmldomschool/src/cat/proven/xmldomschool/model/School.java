package cat.proven.xmldomschool.model;

import java.util.ArrayList;
import java.util.List;

public class School {
    private String name;
    private List<Group> groups;

    public School(String name, List<Group> groups) {
        this.name = name;
        this.groups = groups;
    }

    public School(String name) {
        groups = new ArrayList<Group>();
    }

    public School(School other) {
        this.name = other.name;
        this.groups = other.groups;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }

    @Override
    public String toString() {
        return "School{ " + "name: " + name + ", groups: " + groups + " }";
    }
    
    
    
    
    
    
    
}
