/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cat.proven.xmldomschool.model.persist;

import cat.proven.xmldomschool.model.Group;
import cat.proven.xmldomschool.model.School;
import cat.proven.xmldomschool.model.Student;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 *
 * @author dax
 */
public class XmlDomStudentsPersist {

    private School school;
    private String oFilename; //Output filename

    public XmlDomStudentsPersist(School school, String oFilename) {
        this.school = school;
        this.oFilename = oFilename;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    public String getoFilename() {
        return oFilename;
    }

    public void setoFilename(String oFilename) {
        this.oFilename = oFilename;
    }

    public void saveStudents() {
        try {
            // Create instance of DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Get the DocumentBuilder
            DocumentBuilder docBuilder = factory.newDocumentBuilder();
            // Create blank DOM Document
            Document document = docBuilder.newDocument();
            // create the root element
            Element studentsElement = document.createElement("students");
            //We get the individual student list
            List<Student> students = getStudentsList();
            //We save the students from the list to the file
            for (Student student : students) {
                Element studentElement = createStudentElement(document, student);
                studentsElement.appendChild(studentElement);
            }
            document.appendChild(studentsElement);
            // create transformer.
            TransformerFactory tranformerFactory = TransformerFactory.newInstance();
            Transformer transformer = tranformerFactory.newTransformer();
            // define source and result for tranformer.
            Source source = new DOMSource(document);
            //Result dest = new StreamResult(System.out); 
            Result result = new StreamResult(new File(oFilename));
            transformer.transform(source, result);

        } catch (Exception ex) {
            //TODO catch all exceptions

        }
    }

    //We get the students from the XML file
    public List<Student> getStudentsList() {
        List<Student> students = new ArrayList<Student>();

        for (Group group : this.school.getGroups()) {
            for (Student student : group.getStudents()) {
                students.add(student);
            }
        }
        return students;
    }

    private Element createStudentElement(Document doc, Student student) {
        Element studentElement = doc.createElement("student");
        Element child;
        child = createSimpleTypeElement(doc, "name", student.getName());
        studentElement.appendChild(child);
        child = createSimpleTypeElement(doc, "surname", student.getSurname());
        studentElement.appendChild(child);
        Element emailsElement = createEmailsElement(doc, student);
        studentElement.appendChild(emailsElement);
        child = createSimpleTypeElement(doc, "age", String.valueOf(student.getAge()));
        studentElement.appendChild(child);
        return studentElement;
    }

    private Element createSimpleTypeElement(Document document, String elementName, String elementValue) {
        // create element.
        Element element = document.createElement(elementName);
        // create text node.
        Text textNode = document.createTextNode(elementValue);
        // append text node to element.
        element.appendChild(textNode);
        return element;
    }

    /**
     *
     * @param doc the document file
     * @param student a student Instance
     * @return THe emails element for each student
     */
    private Element createEmailsElement(Document doc, Student student) {
        Element emailsElement = doc.createElement("emails");
        Element child;
        if (!student.getEmails().isEmpty()) {
            for (String email : student.getEmails()) {
                child = createSimpleTypeElement(doc, "email", email);
                emailsElement.appendChild(child);
            }
        } else { //If no emails are found we return null
            return null;
        }
        return emailsElement;
    }
}
