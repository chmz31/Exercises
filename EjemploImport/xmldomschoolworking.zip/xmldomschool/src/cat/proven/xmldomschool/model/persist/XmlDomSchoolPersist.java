package cat.proven.xmldomschool.model.persist;

import cat.proven.xmldomschool.model.Group;
import cat.proven.xmldomschool.model.School;
import cat.proven.xmldomschool.model.Student;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author ProvenSoft
 */
public class XmlDomSchoolPersist {

    private School school;
    private String filename;

    public XmlDomSchoolPersist(String filename) {
        this.filename = filename;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public School loadSchool() {
        School school = null;
        try {
            // create document from XML using DocumentBuilder.
            File file = new File(filename);
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document document = db.parse(file);

            //get root element
            Element schoolElement = document.getDocumentElement();
            schoolElement.normalize();

            //read school data from document
            Element companyNameElement = (Element) schoolElement.getElementsByTagName("name").item(0);
            String name = companyNameElement.getTextContent();

            //get groups
            Element schoolGroupsElement = (Element) schoolElement.getElementsByTagName("groups").item(0);
            List<Group> groups = readSchoolGroups(schoolGroupsElement);

            //Instantiate new school with the data read from XML
            school = new School(name, groups);

        } catch (FileNotFoundException ex) {
            school = null;
        } catch (ParserConfigurationException | SAXException | IOException ex) {
            school = null;
        }
        return school;
    }

    public List<Group> readSchoolGroups(Element schoolGroupsElement) {
        List<Group> l = new ArrayList<Group>();

        NodeList groupNodesList = schoolGroupsElement.getChildNodes();

        for (int i = 0; i < groupNodesList.getLength(); i++) {

            Node groupNode = groupNodesList.item(i);

            if (groupNode instanceof Element groupElement) {
                Group group = readGroup(groupElement);
                l.add(group);
            }
        }
        return l;
    }

    private Group readGroup(Element groupElement) {
        Group group = null;
        try {
            String name = groupElement.getElementsByTagName("name").item(0).getTextContent();
            String tutor = groupElement.getElementsByTagName("tutor").item(0).getTextContent();
            String curriculum = groupElement.getElementsByTagName("curriculum").item(0).getTextContent();
            List<Student> students = readStudents(groupElement.getElementsByTagName("students").item(0));
            group = new Group(name, tutor, curriculum, students);
        } catch (Exception e) {
            group = null;
        }
        return group;
    }

    private List<Student> readStudents(Node studentsNode) {
        List<Student> l = new ArrayList<Student>();

        NodeList studentsNodes = studentsNode.getChildNodes();
        for (int i = 0; i < studentsNodes.getLength(); i++) {
            Node groupNode = studentsNodes.item(i);
            if (groupNode instanceof Element studentElement) {
                Student student = readStudent(studentElement);
                l.add(student);
            }
        }
        return l;
    }

    private Student readStudent(Element studentElement) {
        Student student = null;
        try {
            String id = studentElement.getAttribute("id");
            String name = studentElement.getElementsByTagName("name").item(0).getTextContent();
            String surname = studentElement.getElementsByTagName("surname").item(0).getTextContent();
            List<String> emails = readEmails(studentElement.getElementsByTagName("emails").item(0));
            String sAge = studentElement.getElementsByTagName("age").item(0).getTextContent();

            int age = Integer.parseInt(sAge);
            if (emails.size() >= 1) {
                student = new Student(id, name, surname, emails, age);
            } else {
                student = new Student(id, name, surname, age);
            }

        } catch (Exception ex) {
            student = null;
        }
        return student;
    }

    private List<String> readEmails(Node studentEmailsNode) {
        List<String> l = new ArrayList<String>();

        NodeList emailNodeList = studentEmailsNode.getChildNodes();
        for (int i = 0; i < emailNodeList.getLength(); i++) {
            Node emailNode = emailNodeList.item(i);
            if (emailNode instanceof Element emailElement) {
                String email = emailElement.getChildNodes().item(0).getTextContent();
                l.add(email);
            }
        }
        return l;
    }

    //We get the students from the XML file
    public List<Student> getStudentsList() {
        List<Student> students = new ArrayList<Student>();
        
        for (Group group : this.school.getGroups()) {
            for (Student student : group.getStudents()) {
                students.add(student);
            }
        }
        return students;
    }



}
