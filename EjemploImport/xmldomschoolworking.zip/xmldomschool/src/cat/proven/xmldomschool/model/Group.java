package cat.proven.xmldomschool.model;

import java.util.ArrayList;
import java.util.List;

public class Group {
    private String name;
    private String tutor;
    private String curriculum;
    private List<Student> students;

    public Group(String name, String tutor, String curriculum, List<Student> students) {
        this.name = name;
        this.tutor = tutor;
        this.curriculum = curriculum;
        this.students = students;
    }

    public Group(String name, String tutor, String curriculum) {
        this.name = name;
        this.tutor = tutor;
        this.curriculum = curriculum;
        this.students = new ArrayList<Student>();
    }

    public Group(String name, String tutor) {
        this.name = name;
        this.tutor = tutor;
        this.students = new ArrayList<Student>();
    }

    public Group(String name) {
        this.name = name;
        this.students = new ArrayList<Student>();
    }
    
    public Group(Group other) {
        this.name = other.name;
        this.tutor = other.tutor;
        this.curriculum = other.curriculum;
        this.students = other.students;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTutor() {
        return tutor;
    }

    public void setTutor(String tutor) {
        this.tutor = tutor;
    }

    public String getCurriculum() {
        return curriculum;
    }

    public void setCurriculum(String curriculum) {
        this.curriculum = curriculum;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    @Override
    public String toString() {
        return "\nGroup { " + "name: " + name + ", tutor: " + tutor + ", curriculum: " + curriculum + ", students:" + students + " }";
    }
    
}
