package cat.proven.xmldomschool.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Student {

    private String id;
    private String name;
    private String surname;
    private List<String> emails;
    private int age;

    public Student(String id, String name, String surname, List<String> emails, int age) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.emails = emails;
        this.age = age;
    }

    public Student(String id, String name, String surname, List<String> emails) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.emails = emails;
    }

    public Student(String id, String name, String surname) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.emails = new ArrayList<String>();
    }

    public Student(String id, String name, String surname, int age) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.age = age;
    }

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.emails = new ArrayList<String>();
    }

    public Student(String id) {
        this.id = id;
        this.emails = new ArrayList<String>();
    }

    public Student(Student other) {
        this.id = other.id;
        this.name = other.name;
        this.surname = other.surname;
        this.emails = other.emails;
        this.age = other.age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public List<String> getEmails() {
        return emails;
    }

    public void setEmails(List<String> emails) {
        this.emails = emails;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "\nStudent { " + "name: " + name + ", surname: " + surname + ", emails: " + emails + ", age: " + age + " }";
    }

}
