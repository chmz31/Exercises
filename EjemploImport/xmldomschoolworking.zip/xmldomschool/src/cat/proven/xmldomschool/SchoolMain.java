package cat.proven.xmldomschool;

import cat.proven.xmldomschool.model.Group;
import cat.proven.xmldomschool.model.School;
import cat.proven.xmldomschool.model.Student;
import cat.proven.xmldomschool.model.persist.XmlDomSchoolPersist;
import cat.proven.xmldomschool.model.persist.XmlDomStudentsPersist;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 * Application to manage data of a school. Data is read from an xml file using
 * DOM.
 *
 * @author ProvenSoft
 */
public class SchoolMain {

    private final SchoolMenu mainMenu;
    private boolean exit;

    public SchoolMain() {
        mainMenu = new SchoolMenu();
    }

    public static void main(String[] args) {
        SchoolMain app = new SchoolMain();
        app.run();
    }

    private void run() {
        interact();
    }

    /**
     * VIEW METHODS
     */
    /**
     * Interacts with user. Displays the menu and controls user's actions.
     */
    public void interact() {
        exit = false;
        do {
            //display menu
            mainMenu.show();
            //read user's choice
            String action = mainMenu.getSelectedOptionActionCommand();
            action = (action == null) ? "wrong_option" : action;
            //control action
            executeAction(action);
        } while (!exit);
        showMessage("Exitting application");
    }

    /**
     * Displays a message.
     *
     * @param message to display
     */
    public void showMessage(String message) {
        System.out.println(message);
    }

    /**
     * Prompts a message and reads an input from user
     *
     * @param message the message to prompt
     * @return input from user
     */
    public String prompt(String message) {
        System.out.print(message);
        Scanner sc = new Scanner(System.in);
        return sc.next();
    }

    private void showSchool(School school) {
        System.out.println(school);
    }

    /**
     * asks for confirmation and exits application.
     */
    private void exitApplication() {
        String answer = prompt("Sure to exit? (y/n): ");
        if (answer.toLowerCase().equals("y")) {
            exit = true;
        }
    }

    /**
     * CONTROL METHODS
     */
    /**
     * Processes requests from the view.
     *
     * @param action to execute.
     */
    public void executeAction(String action) {
        switch (action) {
            case "exit":
                exitApplication();
                break;
            case "school/all":
                listSchool();
                break;
            case "students/save":
                saveAllStudents();
                break;

            case "wrong_option":
            default:
                showMessage("Wrong option");
                break;
        }
    }

    private void listSchool() {
        String message;

        //read file name
        String filename = showInputDialog("Input file name: ");

        XmlDomSchoolPersist persister = new XmlDomSchoolPersist(filename);
        School school = persister.loadSchool();

        if (school != null) {
            showMessage("Successfully read");
            showSchool(school);

        } else {
            showMessage("Read fail");
        }

    }

    public String showInputDialog(String message) {
        System.out.print(message);
        Scanner sc = new Scanner(System.in);
        return sc.next();
    }

    private void saveAllStudents() {
        String filename = showInputDialog("Input file name: ");
        String oFilename = showInputDialog("Output file name: ");
        XmlDomSchoolPersist schoolLoad = new XmlDomSchoolPersist(filename);
        School s = schoolLoad.loadSchool();
        
        XmlDomStudentsPersist schoolSave = new XmlDomStudentsPersist(s, oFilename);
        schoolSave.saveStudents();
        
    }

}
